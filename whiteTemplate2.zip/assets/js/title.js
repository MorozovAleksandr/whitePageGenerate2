document.addEventListener('DOMContentLoaded', function () {
    document.querySelector('title').innerHTML = myData.title;
})