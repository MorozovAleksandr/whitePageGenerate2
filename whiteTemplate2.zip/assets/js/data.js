var myData = {
    navbrand: 'Logo', // Домен для вставки в header + footer
    title: 'title', // Заголовок - title, + заголовок страницы
    menuItems: ['link1', 'link2', 'link3', 'link4'], // Пункты меню
    headers: ['first', 'second', 'third'], // заголовки, Крупный текст на фоне картинок
    posts: [`first posts`, `second posts`, `third posts`], // 3 преимущества    
    color: 0, // палитра цвета страницы, выбираем 0-5
    font: 4 // набор шрифтов, выбираем 0-4
};