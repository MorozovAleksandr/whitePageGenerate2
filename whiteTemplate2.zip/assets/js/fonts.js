var myFonts = [
    "font-family: 'Roboto', sans-serif;",
    "font-family: 'Montserrat', sans-serif;",
    "font-family: 'Open Sans', sans-serif;",
    "font-family: 'Source Sans Pro', sans-serif;",
    "font-family: 'Dosis', sans-serif;"
];