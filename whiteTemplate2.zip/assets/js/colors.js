var palette = [{
        bg: 'teal',
        color: ''
    },
    {
        bg: 'pink darken-3',
        color: ''
    },
    {
        bg: 'purple darken-4',
        color: ''
    },
    {
        bg: 'indigo darken-3',
        color: ''
    },
    {
        bg: 'lime darken-4',
        color: ''
    },
    {
        bg: 'orange darken-4',
        color: ''
    }
]